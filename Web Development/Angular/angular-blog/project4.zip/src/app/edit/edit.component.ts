import { Component, OnInit, HostListener } from '@angular/core';
import {Post, BlogService} from '../blog.service';
import { Location } from '@angular/common';
import { Router, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  post:Post;
  postid:number;
  username:string;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private blogService:BlogService) {
    route.paramMap.subscribe(
      () =>{
        this.postid = +this.route.snapshot.paramMap.get('id');
        this.username = this.blogService.parseJWT();
        this.getPost();
      }
    );

  }

  ngOnInit() {
  }

  getPost():void{
    const id = +this.route.snapshot.paramMap.get('id');
    this.blogService.subscribePost(
      posts => this.post = posts.filter(post=>post.postid==id)[0]
    );
    this.post = this.blogService.getPost(this.username, this.postid);
  }
  onDelete():void{
    this.blogService.deletePost(this.username, this.postid);
    this.router.navigate(['/']);
  }
  onPreview():void{
    this.onSave();
    this.router.navigate(['/preview/', this.postid]);
  }
  @HostListener('window:beforeunload')
  onSave():void{
    this.blogService.updatePost(this.username, this.post);
    this.post.modified = new Date();
  }


}
