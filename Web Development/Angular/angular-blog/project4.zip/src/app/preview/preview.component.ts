import { Component, OnInit } from '@angular/core';
import {Post, BlogService} from '../blog.service';
import { Parser, HtmlRenderer } from 'commonmark';
import { Location } from '@angular/common';
import { Router, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})

export class PreviewComponent implements OnInit {
  post:Post;
  postid:number;
  username:string;
  renderedTitle:string;
  renderedBody:string;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private location: Location,
    private blogService:BlogService
  ) {
    route.paramMap.subscribe(
      () =>{
        this.postid = +this.route.snapshot.paramMap.get('id');
        this.username = this.blogService.parseJWT();
        this.getPost();
      }
    );
  }

  ngOnInit() {
  }
  getPost():void{
    let reader = new Parser();
    let writer = new HtmlRenderer();
    const id = +this.route.snapshot.paramMap.get('id');
    this.blogService.subscribePost(
      posts => {
        this.post = posts.filter(post=>post.postid==id)[0];
        this.renderedTitle = writer.render(reader.parse(this.post.title));
        this.renderedBody = writer.render(reader.parse(this.post.body));
      }
    );
    this.post = this.blogService.getPost(this.username, this.postid);
    this.renderedTitle = writer.render(reader.parse(this.post.title));
    this.renderedBody = writer.render(reader.parse(this.post.body));
  }

  goBack():void{
    this.location.back();
  }
}
