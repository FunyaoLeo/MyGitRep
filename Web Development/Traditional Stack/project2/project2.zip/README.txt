Develop a Web application using a "traditional" stack, in particular, MySQL and Apache Tomcat (Java servlet). This is an "online markdown editor" that allows users to save and edit blog posts written in markdown language.

Environment(Docker image: "junghoo/cs144-tomcat"):

MySQL
Apache Tomcat
Java JDK 7
REST API: /editor/post?action=type&username=name&postid=num&title=title&body=body

action:

open
save
list
delete
post